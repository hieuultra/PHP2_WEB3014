<?= $user['first_name'] . "" . $user['last_name'] ?>
<form action="" method="post">
    <input type="email" name="" id="">
    <input type="submit" value="">
</form>