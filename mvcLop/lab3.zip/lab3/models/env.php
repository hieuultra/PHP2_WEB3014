<?php 
// cấu hình thông tin cơ sở dữ liệu
    const DBNAME = "wd18303";
    const DBUSER = "root";
    const DBPASS = "";
    const DBCHARSET = "utf8";
    const DBHOST = "127.0.0.1";
?>