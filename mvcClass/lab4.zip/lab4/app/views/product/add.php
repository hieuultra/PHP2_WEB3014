
    <form action="" method="post">
        <input type="text" name="name" >
        <input type="text" name="price" >
        <input type="text" name="quantity" >
        <input type="submit" value="ADD" name ="add" >
    </form>
